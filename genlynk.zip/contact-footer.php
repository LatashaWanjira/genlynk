<div class="contacts pt-5">
            <div class="container">
                <h2>Contact Us</h2>
                <hr>
                <div class="row  justify-content-center py-4 align-items-center">
                    <div class="col-md-6">
                        <h4>Highway Digital Nigeria Limited</h4>
                        <ul>
                            <li>Block 116, Plot 16A, George Omonubi Street, Lekki</li>
                            <li>Lagos, Nigeria</li>
                        </ul>
                    </div>
                    <div class="col-md-6 social">
                        <h4>Find Us</h4>
                        <p><i class="fas fa-envelope"></i> info@genlynk.com.ng</p>
                        <p><i class="fas fa-phone"></i>+234 809 777 1113</p>
                        <a href="#" class="p-1"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="p-1"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="p-1"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer">
            <p>
                &copy; GenLynk
                <script type="text/javascript">
                    document.write(new Date().getFullYear());
                </script>
            <span style="float: right;" class="mr-5"><a href="/faq.php">FAQs</a></span>
          </p>
        </div>
