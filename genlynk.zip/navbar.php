<style>
        a:hover{color:white;}
    </style>
<nav class="navbar fixed-top navbar-expand-lg">
    <h3 class="navbar-brand" ><a href="/">GenLynk</a></h3>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#genlynkNavbar" aria-controls="genlynkNavbar" aria-expanded="false" aria-label="Toggle navigation"><span class="fas fa-bars"></span></button>
    <div class="collapse navbar-collapse" id="genlynkNavbar">
        <ul class="navbar-nav mr-0 ml-auto my-2 my-lg-0">
            <li class="nav-item">
                <a class="nav-link" href="index.php">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="install.php">Install</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="our-products.php">Our Products</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="partner-with-us.php">Partner With Us</a>
            </li>
        </ul>
    </div>
</nav>
